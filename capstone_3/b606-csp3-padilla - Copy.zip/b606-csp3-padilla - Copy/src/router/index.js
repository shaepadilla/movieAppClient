import { createRouter, createWebHistory } from 'vue-router'

import HomeView from '../views/HomeView.vue'
import RegisterView from '../views/RegisterView.vue'
import LoginView from '../views/LoginView.vue'
import ProductsView from '../views/ProductsView.vue'
import ProductDetailsView from '../views/ProductDetailsView.vue'
import CartView from '../views/CartView.vue'
import OrdersView from '../views/OrdersView.vue'
import AdminDashboardView from '../views/AdminDashboardView.vue'

const routes = [

    {
        path: '/',
        name: 'home',
        component: HomeView
    },

    {
        path: '/register',
        name: 'register',
        component: RegisterView
    },

    {
        path: '/login',
        name: 'login',
        component: LoginView
    },

    {
        path: '/products',
        name: 'products',
        component: ProductsView
    },

    {
        path: '/products/:productId',
        name: 'productDetails',
        component: ProductDetailsView
    },

    {
        path: '/cart',
        name: 'cart',
        component: CartView
    },

    {
        path: '/orders',
        name: 'orders',
        component: OrdersView
    },

    {
        path: '/admin/dashboard',
        name: 'adminDashboard',
        component: AdminDashboardView,

        meta: {
            requiresAdmin: true
        }
    }

]

const router = createRouter({

    history: createWebHistory(),
    routes

})

router.beforeEach((to, from, next) => {

    const token = localStorage.getItem('token')

    const isAdmin =
        localStorage.getItem('isAdmin') === 'true'

    // PROTECT ADMIN ROUTE
    if (to.meta.requiresAdmin) {

        if (!token || !isAdmin) {

            return next('/login')
        }

    }

    next()

})

export default router