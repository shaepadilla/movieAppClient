<template>
  <div class="container mt-5">
    <h1 class="mb-4">Admin Dashboard</h1>

    <div class="row">
      <div class="col-md-4 mb-3">
        <div class="card p-3 shadow-sm">
          <h5>Total Products</h5>
          <h2>{{ totalProducts }}</h2>
        </div>
      </div>

      <div class="col-md-4 mb-3">
        <div class="card p-3 shadow-sm">
          <h5>Total Orders</h5>
          <h2>{{ totalOrders }}</h2>
        </div>
      </div>

      <div class="col-md-4 mb-3">
        <div class="card p-3 shadow-sm">
          <h5>Total Users</h5>
          <h2>{{ totalUsers }}</h2>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'

const products = ref([
  {
    id: 1,
    name: 'Smartphone',
    price: 699,
    stock: 15
  },
  {
    id: 2,
    name: 'Laptop',
    price: 999,
    stock: 3
  },
  {
    id: 3,
    name: 'Headphones',
    price: 89,
    stock: 42
  },
  {
    id: 4,
    name: 'Keyboard',
    price: 59,
    stock: 7
  },
  {
    id: 5,
    name: 'Mouse',
    price: 29,
    stock: 28
  }
])

const orders = ref([
  {
    id: '#1001',
    customer: 'John Doe',
    total: 698,
    status: 'Pending'
  },
  {
    id: '#1002',
    customer: 'Jane Smith',
    total: 999,
    status: 'Processing'
  },
  {
    id: '#1003',
    customer: 'Bob Johnson',
    total: 118,
    status: 'Delivered'
  },
  {
    id: '#1004',
    customer: 'Alice Brown',
    total: 29,
    status: 'Shipped'
  },
  {
    id: '#1005',
    customer: 'Charlie Wilson',
    total: 59,
    status: 'Cancelled'
  }
])

const users = ref([
  {
    id: 1,
    name: 'John Doe'
  },
  {
    id: 2,
    name: 'Jane Smith'
  },
  {
    id: 3,
    name: 'Bob Johnson'
  }
])

const totalProducts = computed(() => {
  return products.value.length
})

const totalOrders = computed(() => {
  return orders.value.length
})

const totalUsers = computed(() => {
  return users.value.length
})
</script>