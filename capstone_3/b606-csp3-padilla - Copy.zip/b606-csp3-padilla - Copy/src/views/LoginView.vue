<template>

    <div class="container mt-5">

        <div class="row justify-content-center">

            <div class="col-md-5">

                <div class="card shadow">

                    <div class="card-body">

                        <h2 class="text-center mb-4">
                            Login
                        </h2>

                        <form @submit.prevent="loginUser">

                            <!-- EMAIL -->
                            <div class="mb-3">

                                <label class="form-label">
                                    Email
                                </label>

                                <input
                                    type="email"
                                    class="form-control"
                                    v-model="email"
                                    required
                                >

                            </div>

                            <!-- PASSWORD -->
                            <div class="mb-3">

                                <label class="form-label">
                                    Password
                                </label>

                                <input
                                    type="password"
                                    class="form-control"
                                    v-model="password"
                                    required
                                >

                            </div>

                            <button
                                type="submit"
                                class="btn btn-primary w-100"
                                :disabled="isLoading"
                            >

                                {{
                                    isLoading
                                    ? 'Logging in...'
                                    : 'Login'
                                }}

                            </button>

                        </form>

                        <!-- SUCCESS MESSAGE -->
                        <div
                            v-if="successMessage"
                            class="alert alert-success mt-3"
                        >
                            {{ successMessage }}
                        </div>

                        <!-- ERROR MESSAGE -->
                        <div
                            v-if="errorMessage"
                            class="alert alert-danger mt-3"
                        >
                            {{ errorMessage }}
                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</template>

<!-- views/LoginView.vue -->

<script setup>
// Add this to your existing login function
const loginUser = async () => {
    errorMessage.value = ""
    isLoading.value = true
    
    try {
        const response = await axios.post("http://localhost:4000/users/login", {
            email: email.value,
            password: password.value
        })
        
        // Store both token AND isAdmin
        localStorage.setItem("token", response.data.access)
        localStorage.setItem("isAdmin", response.data.isAdmin)  // IMPORTANT!
        
        successMessage.value = "Login successful! Redirecting..."
        
        setTimeout(() => {
            if (response.data.isAdmin) {
                router.push("/admin/dashboard")
            } else {
                router.push("/products")
            }
        }, 1500)
        
    } catch(error) {
        if(error.response) {
            errorMessage.value = error.response.data.message
        } else {
            errorMessage.value = "Cannot connect to server"
        }
    } finally {
        isLoading.value = false
    }
}
</script>