<template>

    <div class="container py-5">

        <h1 class="text-center mb-5">
            Product Details
        </h1>

        <div class="row bg-white shadow rounded p-4">

            <!-- PRODUCT IMAGE -->
            <div class="col-md-6 mb-4">

                <div class="product-image">

                    <span>
                        Sample Product Image
                    </span>

                </div>

            </div>

            <!-- PRODUCT INFO -->
            <div class="col-md-6">

                <h2 class="mb-3">
                    {{ product.name }}
                </h2>

                <h5 class="fw-bold">
                    Description:
                </h5>

                <p class="mb-4">
                    {{ product.description }}
                </p>

                <h4 class="fw-bold mb-4">
                    Price: {{ product.price }}
                </h4>

                <p class="mb-4">
                    Php {{ product.price }}
                </p>

                <!-- QUANTITY -->
                <h5 class="fw-bold">
                    Quantity:
                </h5>

                <div class="d-flex align-items-center mb-4">

                    <button
                        class="btn btn-outline-secondary"
                        @click="decreaseQty"
                    >
                        -
                    </button>

                    <input
                        type="text"
                        class="form-control text-center mx-2 quantity-input"
                        :value="quantity"
                        readonly
                    >

                    <button
                        class="btn btn-outline-secondary"
                        @click="increaseQty"
                    >
                        +
                    </button>

                </div>

                <div
                    v-if="successMessage"
                    class="alert alert-success"
                >
                    {{ successMessage }}
                </div>

                <!-- ADD TO CART -->
                <button
                    class="btn btn-success px-4"
                    @click="addToCart"
                >
                    Add to Cart
                </button>

            </div>

        </div>

    </div>

</template>

<script setup>

import { ref, onMounted } from 'vue'
import axios from 'axios'
import { useRoute } from 'vue-router'

const route = useRoute()

const product = ref({})
const quantity = ref(1)

const successMessage = ref("")

const token = localStorage.getItem("token")

const getProduct = async () => {

    try {

        const response = await axios.get(
            `http://localhost:4000/products/${route.params.productId}`
        )

        product.value = response.data

    } catch(error){

        console.log(error)
    }
}

const increaseQty = () => {
    quantity.value++
}

const decreaseQty = () => {

    if(quantity.value > 1){
        quantity.value--
    }
}

const addToCart = async () => {

    try {

        await axios.post(
            "http://localhost:4000/cart/add-to-cart",
            {
                productId: product.value._id,
                quantity: quantity.value
            },
            {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            }
        )

        successMessage.value = "Added to cart successfully!"

        setTimeout(() => {
            successMessage.value = ""
        }, 3000)

    } catch(error){

        console.log(error)
    }
}

onMounted(() => {
    getProduct()
})

</script>

<style scoped>

.product-image {

    height: 400px;
    background: #ddd;

    display: flex;
    justify-content: center;
    align-items: center;

    font-size: 2rem;
    color: #999;
    font-weight: bold;
}

.quantity-input {

    width: 100px;
}

</style>