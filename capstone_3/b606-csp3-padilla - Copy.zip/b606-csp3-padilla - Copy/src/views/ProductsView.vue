<template>

    <div class="container mt-5">

        <h1 class="mb-4">
            Our Products
        </h1>

        <!-- Loading -->
        <div
            v-if="loading"
            class="text-center"
        >
            Loading products...
        </div>

        <!-- Products -->
        <div class="row">

            <div
                class="col-md-4 mb-4"
                v-for="product in products"
                :key="product._id"
            >

                <div class="card h-100 shadow">

                    <div class="card-body d-flex flex-column">

                      <h5 class="card-title">
                             {{ product.name }}
                     </h5>

                        <p>
                             {{ product._id }}
                        </p>

                        <p class="card-text">
                            {{ product.description }}
                        </p>

                        <h6 class="mb-3">
                            ₱ {{ product.price }}
                        </h6>

                        <router-link
                            :to="`/products/${product._id}`"
                            class="btn btn-primary mt-auto"
                        >
                            Details
                        </router-link>

                    </div>

                </div>

            </div>

        </div>

    </div>

</template>

<script setup>

import { ref, onMounted } from 'vue'
import axios from 'axios'

const products = ref([])
const loading = ref(true)

const getProducts = async () => {

    try {

        const response = await axios.get(
            'http://localhost:4000/products/active'
        )

        console.log(response.data)

        products.value =
            response.data.products ||
            response.data

    } catch(error){

        console.log(error)
    }
}

onMounted(() => {

    getProducts()
})

</script>