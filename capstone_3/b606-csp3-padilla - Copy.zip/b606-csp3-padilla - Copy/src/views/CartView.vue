<template>

    <div class="container mt-5">

        <h1 class="mb-4">
            Your Shopping Cart
        </h1>

        <!-- EMPTY CART -->
        <div
            v-if="cartItems.length === 0"
            class="alert alert-warning"
        >
            Cart is empty
        </div>

        <!-- CART TABLE -->
        <table
            v-else
            class="table table-bordered"
        >

            <thead class="table-dark">

                <tr>

                    <th>Name</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Subtotal</th>
                    <th>Action</th>

                </tr>

            </thead>

            <tbody>

                <tr
                    v-for="item in cartItems"
                    :key="item.productId._id"
                >

                    <!-- PRODUCT NAME -->
                    <td>
                        {{ item.productId.name }}
                    </td>

                    <!-- PRODUCT PRICE -->
                    <td>
                        ₱ {{ item.productId.price }}
                    </td>

                    <!-- QUANTITY -->
                    <td>

                        <div
                            class="d-flex align-items-center gap-2"
                        >

                            <button
                                class="btn btn-dark btn-sm"
                                @click="decreaseQuantity(item)"
                            >
                                -
                            </button>

                            <span>
                                {{ item.quantity }}
                            </span>

                            <button
                                class="btn btn-dark btn-sm"
                                @click="increaseQuantity(item)"
                            >
                                +
                            </button>

                        </div>

                    </td>

                    <!-- SUBTOTAL -->
                    <td>
                        ₱ {{
                            item.productId.price
                            * item.quantity
                        }}
                    </td>

                    <!-- REMOVE -->
                    <td>

                        <button
                            class="btn btn-danger btn-sm"
                            @click="removeItem(item.productId._id)"
                        >
                            Remove
                        </button>

                    </td>

                </tr>

            </tbody>

        </table>

        <!-- TOTAL -->
        <div
            v-if="cartItems.length > 0"
            class="d-flex justify-content-between align-items-center"
        >

            <h3>
                Total: ₱ {{ totalPrice }}
            </h3>

            <div>

                <button
                    class="btn btn-warning me-2"
                    @click="clearCart"
                >
                    Clear Cart
                </button>

                <button
                    class="btn btn-success"
                    @click="checkout"
                >
                    Checkout
                </button>

            </div>

        </div>

        <!-- SUCCESS -->
        <div
            v-if="successMessage"
            class="alert alert-success mt-3"
        >
            {{ successMessage }}
        </div>

        <!-- ERROR -->
        <div
            v-if="errorMessage"
            class="alert alert-danger mt-3"
        >
            {{ errorMessage }}
        </div>

    </div>

</template>

<script setup>

import {
    ref,
    computed,
    onMounted
} from "vue"

import axios from "axios"

const cartItems = ref([])

const successMessage = ref("")
const errorMessage = ref("")

const token = localStorage.getItem("token")

// TOTAL PRICE
const totalPrice = computed(() => {

    return cartItems.value.reduce(

        (total, item) => {

            return total + (
                item.productId.price
                * item.quantity
            )

        },

        0
    )
})

// GET CART
const getCart = async () => {

    try {

        const response = await axios.get(
            'http://localhost:4000/cart/get-cart',
            {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            }
        )

        cartItems.value =
            response.data.cart.cartItems

        // CLEAR MESSAGES
        if(cartItems.value.length === 0){
            successMessage.value = ''
        }

    } catch(error){

        console.log(error)
    }
}

// INCREASE QUANTITY
const increaseQuantity = async (item) => {

    item.quantity++

    await updateQuantity(
        item.productId._id,
        item.quantity
    )
}

// DECREASE QUANTITY
const decreaseQuantity = async (item) => {

    if(item.quantity > 1){

        item.quantity--

        await updateQuantity(
            item.productId._id,
            item.quantity
        )
    }
}

// UPDATE QUANTITY
const updateQuantity = async (
    productId,
    quantity
) => {

    try {

        await axios.patch(

            `http://localhost:4000/cart/update-cart-quantity/${productId}`,

            {
                quantity
            },

            {
                headers: {
                    Authorization:
                        `Bearer ${token}`
                }
            }
        )

    } catch(error){

        console.log(error)
    }
}

// REMOVE ITEM
const removeItem = async (productId) => {
    try {
        // Change this:
        // `http://localhost:4000/cart/remove-from-cart/${productId}`
        
        // To this:
        await axios.patch(
            `http://localhost:4000/cart/${productId}/remove-from-cart`,  // productId comes BEFORE remove-from-cart
            {},
            {
                headers: { Authorization: `Bearer ${token}` }
            }
        )

        successMessage.value = "Item removed"
        getCart()
    } catch(error){
        console.log(error)
        errorMessage.value = "Failed to remove item"
    }
}

// CLEAR CART
const clearCart = async () => {

    try {

        await axios.patch(

            "http://localhost:4000/cart/clear-cart",

            {},

            {
                headers: {
                    Authorization:
                        `Bearer ${token}`
                }
            }
        )

        successMessage.value =
            "Cart cleared"

        getCart()

    } catch(error){

        console.log(error)
    }
}

// CHECKOUT
const checkout = async () => {

    try {

        await axios.post(

            "http://localhost:4000/orders/checkout",

            {},

            {
                headers: {
                    Authorization:
                        `Bearer ${token}`
                }
            }
        )

        successMessage.value =
            "Checkout successful"

        getCart()

    } catch(error){

        console.log(error)

        errorMessage.value =
            "Checkout failed"
    }
}

onMounted(() => {

    getCart()
})

</script>