<template>

    <!-- HERO SECTION -->
    <section class="hero-section">

        <div class="container">

            <div class="hero-content">

                <h1>
                    Welcome to DigiMart
                </h1>

                <p>
                    We sell gadgets and tech products that
                    will make your life easier and more fun.
                    From smartphones and laptops to gaming
                    consoles and smart home devices,
                    we have it all.
                </p>

                <button
                    class="btn btn-primary px-5 py-3 mt-4"
                    @click="toggleProducts"
                >
                    See Our Products →
                </button>

            </div>

        </div>

    </section>

    <!-- FEATURED PRODUCTS -->
    <section
        v-if="showProducts"
        id="featured-products"
        class="container py-5"
    >

        <h2 class="section-title mb-5">
            Featured Products
        </h2>

        <div class="products-grid">

            <div
                class="card p-4"
                v-for="product in products"
                :key="product._id"
            >

                <div class="card-body d-flex flex-column">

                    <h5 class="card-title mb-3">
                        {{ product.name }}
                    </h5>

                    <p class="card-text flex-grow-1">
                        {{ product.description }}
                    </p>

                    <p>{{ product._id }}</p>

                    <h5 class="mb-4">
                        ₱ {{ product.price }}
                    </h5>

                    <router-link
                        :to="`/products/${product._id}`"
                    >
                        <button class="btn btn-primary w-100">
                            Details
                        </button>
                    </router-link>

                </div>

            </div>

        </div>

    </section>

    <!-- WHY CHOOSE US -->
    <section class="container py-5">

        <h2 class="section-title mb-5">
            Why Choose Us
        </h2>

        <div class="row g-4">

            <div class="col-md-3">
                <div class="card p-4 text-center h-100">

                    <h4 class="mb-3">
                        🚚
                    </h4>

                    <h5>
                        Fast Delivery
                    </h5>

                    <p>
                        Quick and reliable shipping
                        nationwide.
                    </p>

                </div>
            </div>

            <div class="col-md-3">
                <div class="card p-4 text-center h-100">

                    <h4 class="mb-3">
                        🔒
                    </h4>

                    <h5>
                        Secure Checkout
                    </h5>

                    <p>
                        Safe and protected online
                        transactions.
                    </p>

                </div>
            </div>

            <div class="col-md-3">
                <div class="card p-4 text-center h-100">

                    <h4 class="mb-3">
                        💰
                    </h4>

                    <h5>
                        Affordable Prices
                    </h5>

                    <p>
                        Great products at budget-friendly
                        prices.
                    </p>

                </div>
            </div>

            <div class="col-md-3">
                <div class="card p-4 text-center h-100">

                    <h4 class="mb-3">
                        ⭐
                    </h4>

                    <h5>
                        Premium Quality
                    </h5>

                    <p>
                        Carefully selected products
                        you can trust.
                    </p>

                </div>
            </div>

        </div>

    </section>


</template>

<script setup>

import { ref } from "vue";
import axios from "axios";
import { onMounted } from "vue";

const showProducts = ref(false);

const products = ref([]);

const getProducts = async () => {

    try {

        const response = await axios.get(
            "http://localhost:4000/products/active"
        );

        products.value = response.data;

    } catch(error){

        console.log(error);
    }
};

const toggleProducts = () => {

    showProducts.value = true;

    setTimeout(() => {

        document
            .getElementById("featured-products")
            ?.scrollIntoView({
                behavior: "smooth"
            });

    }, 100);

};

onMounted(() => {
    getProducts();
});

</script>