<template>

    <div class="container mt-5">

        <div class="row justify-content-center">

            <div class="col-md-6">

                <div class="card shadow">

                    <div class="card-body">

                        <h2 class="text-center mb-4">
                            Register
                        </h2>

                        <form @submit.prevent="registerUser">

                            <!-- First Name -->
                            <div class="mb-3">

                                <label class="form-label">
                                    First Name
                                </label>

                                <input
                                    type="text"
                                    class="form-control"
                                    v-model="firstName"
                                    required
                                >

                            </div>

                            <!-- Last Name -->
                            <div class="mb-3">

                                <label class="form-label">
                                    Last Name
                                </label>

                                <input
                                    type="text"
                                    class="form-control"
                                    v-model="lastName"
                                    required
                                >

                            </div>

                            <!-- Email -->
                            <div class="mb-3">

                                <label class="form-label">
                                    Email
                                </label>

                                <input
                                    type="email"
                                    class="form-control"
                                    v-model="email"
                                    required
                                >

                            </div>

                            <!-- Mobile Number -->
                            <div class="mb-3">

                                <label class="form-label">
                                    Mobile Number
                                </label>

                                <input
                                    type="text"
                                    class="form-control"
                                    v-model="mobileNo"
                                    required
                                >

                            </div>

                            <!-- Password -->
                            <div class="mb-3">

                                <label class="form-label">
                                    Password
                                </label>

                                <input
                                    type="password"
                                    class="form-control"
                                    v-model="password"
                                    required
                                >

                            </div>

                            <!-- Verify Password -->
                            <div class="mb-3">

                                <label class="form-label">
                                    Verify Password
                                </label>

                                <input
                                    type="password"
                                    class="form-control"
                                    v-model="verifyPassword"
                                    required
                                >

                            </div>

                            <!-- Button -->
                            <button
                                type="submit"
                                class="btn btn-primary w-100"
                                :disabled="isLoading"
                            >

                                {{
                                    isLoading
                                    ? 'Registering...'
                                    : 'Register'
                                }}

                            </button>

                        </form>

                        <!-- Error -->
                        <div
                            v-if="errorMessage"
                            class="alert alert-danger mt-3"
                        >
                            {{ errorMessage }}
                        </div>

                        <!-- Success -->
                        <div
                            v-if="successMessage"
                            class="alert alert-success mt-3"
                        >
                            {{ successMessage }}
                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</template>

<script setup>

import { ref } from 'vue'
import axios from 'axios'
import { useRouter } from 'vue-router'

const router = useRouter()

const firstName = ref('')
const lastName = ref('')
const email = ref('')
const mobileNo = ref('')
const password = ref('')
const verifyPassword = ref('')

const errorMessage = ref('')
const successMessage = ref('')
const isLoading = ref(false)

const registerUser = async () => {

    errorMessage.value = ''
    successMessage.value = ''

    if(password.value !== verifyPassword.value){

        errorMessage.value = 'Passwords do not match'
        return
    }

    try{

        isLoading.value = true

        console.log("Submitting registration...")

        const response = await axios.post(
            'http://localhost:4000/users/register',
            {
                firstName: firstName.value,
                lastName: lastName.value,
                email: email.value,
                mobileNo: mobileNo.value,
                password: password.value
            }
        )

        console.log("SUCCESS:", response.data)

        successMessage.value = 'Registration successful'

        setTimeout(() => {
            router.push('/login')
        }, 1500)

    } catch(error){

        console.log("FULL ERROR:", error)

        if(error.response){

            console.log("SERVER ERROR:", error.response.data)

            errorMessage.value =
                error.response.data.message ||
                'Registration failed'
        }

        else if(error.request){

            console.log("NO RESPONSE FROM SERVER")

            errorMessage.value =
                'Cannot connect to server'
        }

        else{

            console.log("REQUEST ERROR:", error.message)

            errorMessage.value =
                error.message
        }

    } finally{

        isLoading.value = false
    }
}

</script>