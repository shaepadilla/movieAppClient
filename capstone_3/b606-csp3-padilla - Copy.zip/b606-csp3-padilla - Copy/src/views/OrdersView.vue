<template>

    <div class="container mt-5">

        <h1 class="mb-4">
            My Orders
        </h1>

        <!-- No Orders -->
        <div
            v-if="orders.length === 0"
            class="alert alert-warning"
        >
            No orders found
        </div>

        <!-- Orders -->
        <div
            v-for="order in orders"
            :key="order._id"
            class="card shadow mb-4"
        >

            <div class="card-body">

                <!-- Header -->
                <div class="d-flex justify-content-between mb-3">

                    <div>

                        <h5>
                            Order ID
                        </h5>

                        <p>
                            {{ order._id }}
                        </p>

                    </div>

                    <div>

                        <h5>
                            Total Price
                        </h5>

                        <p>
                            ₱ {{ order.totalPrice }}
                        </p>

                    </div>

                </div>

                <!-- Status -->
                <div class="mb-3">

                    <span class="badge bg-success">

                        {{ order.status }}

                    </span>

                </div>

                <!-- Products -->
                <table class="table table-bordered">

                    <thead class="table-dark">

                        <tr>

                            <th>Product ID</th>
                            <th>Quantity</th>
                            <th>Subtotal</th>

                        </tr>

                    </thead>

                    <tbody>

                        <tr
                            v-for="item in order.productsOrdered"
                            :key="item.productId"
                        >

                            <td>
                                {{ item.productId }}
                            </td>

                            <td>
                                {{ item.quantity }}
                            </td>

                            <td>
                                ₱ {{ item.subtotal }}
                            </td>

                        </tr>

                    </tbody>

                </table>

                <!-- Ordered Date -->
                <div class="mt-3">

                    <strong>
                        Ordered On:
                    </strong>

                    {{
                        new Date(
                            order.orderedOn
                        ).toLocaleString()
                    }}

                </div>

            </div>

        </div>

    </div>

</template>

<script setup>

import { ref, onMounted } from 'vue'
import axios from 'axios'

const orders = ref([])

const token = localStorage.getItem('token')

const getOrders = async () => {

    try {

        const response = await axios.get(
            'http://localhost:4000/orders/my-orders',
            {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            }
        )

        orders.value = response.data.orders

    } catch(error){

        console.log(error)
    }
}

onMounted(() => {

    getOrders()
})

</script>