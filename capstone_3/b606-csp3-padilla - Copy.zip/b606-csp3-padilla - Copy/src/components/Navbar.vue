<template>
  <div class="min-h-screen bg-gray-100 p-6">
    <!-- Header -->
    <div
      class="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6"
    >
      <div>
        <h1 class="text-3xl font-bold">Admin Dashboard</h1>
        <p class="text-muted-foreground">
          {{ currentDate }}
        </p>
      </div>

      <Button @click="resetData" variant="destructive">
        Reset Mock Data
      </Button>
    </div>

    <!-- Stats -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
      <Card>
        <CardContent class="p-6">
          <p class="text-muted-foreground">Total Products</p>
          <h2 class="text-3xl font-bold mt-2">
            {{ totalProducts }}
          </h2>
        </CardContent>
      </Card>

      <Card>
        <CardContent class="p-6">
          <p class="text-muted-foreground">Total Orders</p>
          <h2 class="text-3xl font-bold mt-2">
            {{ totalOrders }}
          </h2>
        </CardContent>
      </Card>

      <Card>
        <CardContent class="p-6">
          <p class="text-muted-foreground">Total Revenue</p>
          <h2 class="text-3xl font-bold mt-2">
            ${{ totalRevenue }}
          </h2>
        </CardContent>
      </Card>

      <Card>
        <CardContent class="p-6">
          <p class="text-muted-foreground">Low Stock Items</p>
          <h2 class="text-3xl font-bold mt-2 text-red-500">
            {{ lowStockItems }}
          </h2>
        </CardContent>
      </Card>
    </div>

    <!-- Tabs -->
    <Tabs default-value="products">
      <TabsList class="mb-6">
        <TabsTrigger value="products">Products</TabsTrigger>
        <TabsTrigger value="orders">Orders</TabsTrigger>
      </TabsList>

      <!-- PRODUCTS -->
      <TabsContent value="products">
        <Card>
          <CardHeader
            class="flex flex-col md:flex-row md:items-center md:justify-between gap-4"
          >
            <div>
              <CardTitle>Product Management</CardTitle>
            </div>

            <div class="flex gap-2">
              <Input
                v-model="search"
                placeholder="Search products..."
                class="w-[250px]"
              />

              <Dialog v-model:open="productDialog">
                <DialogTrigger as-child>
                  <Button @click="openAddProduct">
                    Add Product
                  </Button>
                </DialogTrigger>

                <DialogContent class="sm:max-w-[500px]">
                  <DialogHeader>
                    <DialogTitle>
                      {{ editingProduct ? "Edit Product" : "Add Product" }}
                    </DialogTitle>
                  </DialogHeader>

                  <div class="space-y-4 mt-4">
                    <div>
                      <label class="text-sm font-medium">Name</label>
                      <Input v-model="productForm.name" />
                    </div>

                    <div>
                      <label class="text-sm font-medium">
                        Description
                      </label>
                      <Input v-model="productForm.description" />
                    </div>

                    <div>
                      <label class="text-sm font-medium">Price</label>
                      <Input
                        type="number"
                        v-model="productForm.price"
                      />
                    </div>

                    <div>
                      <label class="text-sm font-medium">Stock</label>
                      <Input
                        type="number"
                        v-model="productForm.stock"
                      />
                    </div>

                    <div>
                      <label class="text-sm font-medium">
                        Image URL
                      </label>
                      <Input v-model="productForm.image" />
                    </div>

                    <div
                      v-if="formError"
                      class="text-red-500 text-sm"
                    >
                      {{ formError }}
                    </div>

                    <Button
                      class="w-full"
                      @click="saveProduct"
                    >
                      Save Product
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>

          <CardContent>
            <div class="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Price</TableHead>
                    <TableHead>Stock</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>

                <TableBody>
                  <TableRow
                    v-for="product in filteredProducts"
                    :key="product.id"
                  >
                    <TableCell class="font-medium">
                      <div class="flex items-center gap-3">
                        <img
                          :src="product.image"
                          class="w-12 h-12 rounded object-cover"
                        />

                        {{ product.name }}
                      </div>
                    </TableCell>

                    <TableCell>
                      ${{ product.price }}
                    </TableCell>

                    <TableCell>
                      <span
                        :class="
                          product.stock < 10
                            ? 'text-red-500 font-bold'
                            : ''
                        "
                      >
                        {{ product.stock }}
                      </span>
                    </TableCell>

                    <TableCell>
                      <Badge
                        :variant="
                          product.stock < 10
                            ? 'destructive'
                            : 'default'
                        "
                      >
                        {{
                          product.stock < 10
                            ? 'Low Stock'
                            : 'In Stock'
                        }}
                      </Badge>
                    </TableCell>

                    <TableCell class="space-x-2">
                      <Button
                        size="sm"
                        variant="outline"
                        @click="editProduct(product)"
                      >
                        Edit
                      </Button>

                      <Button
                        size="sm"
                        variant="destructive"
                        @click="deleteProduct(product.id)"
                      >
                        Delete
                      </Button>
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </TabsContent>

      <!-- ORDERS -->
      <TabsContent value="orders">
        <Card>
          <CardHeader>
            <CardTitle>Order Management</CardTitle>
          </CardHeader>

          <CardContent>
            <div class="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Order ID</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Total</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>

                <TableBody>
                  <TableRow
                    v-for="order in orders"
                    :key="order.id"
                  >
                    <TableCell>{{ order.id }}</TableCell>

                    <TableCell>
                      {{ order.customer }}
                    </TableCell>

                    <TableCell>{{ order.date }}</TableCell>

                    <TableCell>
                      ${{ order.total }}
                    </TableCell>

                    <TableCell>
                      <Select
                        :model-value="order.status"
                        @update:model-value="
                          value => order.status = value
                        "
                      >
                        <SelectTrigger class="w-[160px]">
                          <SelectValue />
                        </SelectTrigger>

                        <SelectContent>
                          <SelectItem value="Pending">
                            Pending
                          </SelectItem>

                          <SelectItem value="Processing">
                            Processing
                          </SelectItem>

                          <SelectItem value="Shipped">
                            Shipped
                          </SelectItem>

                          <SelectItem value="Delivered">
                            Delivered
                          </SelectItem>

                          <SelectItem value="Cancelled">
                            Cancelled
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </TableCell>

                    <TableCell>
                      <Button
                        size="sm"
                        @click="viewOrder(order)"
                      >
                        View Details
                      </Button>
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>

    <!-- ORDER DETAILS MODAL -->
    <Dialog v-model:open="orderDialog">
      <DialogContent class="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>
            Order Details
          </DialogTitle>
        </DialogHeader>

        <div v-if="selectedOrder" class="space-y-4">
          <div>
            <h3 class="font-semibold mb-2">
              Order Information
            </h3>

            <p><strong>ID:</strong> {{ selectedOrder.id }}</p>
            <p>
              <strong>Customer:</strong>
              {{ selectedOrder.customer }}
            </p>

            <p>
              <strong>Status:</strong>
              {{ selectedOrder.status }}
            </p>
          </div>

          <div>
            <h3 class="font-semibold mb-2">
              Items
            </h3>

            <div
              v-for="item in selectedOrder.items"
              :key="item.name"
              class="border rounded-lg p-3 mb-2"
            >
              <p>{{ item.name }}</p>
              <p>Qty: {{ item.quantity }}</p>
              <p>${{ item.subtotal }}</p>
            </div>
          </div>

          <div>
            <h3 class="font-semibold mb-2">
              Shipping Address
            </h3>

            <p>
              123 Main St, City, Country
            </p>
          </div>

          <div>
            <h3 class="font-semibold mb-2">
              Payment Method
            </h3>

            <p>
              Credit Card ending in 4242
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  </div>
</template>

<script setup>
import { ref, reactive, computed } from "vue"

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"

import { Button } from "@/components/ui/button"

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

import { Input } from "@/components/ui/input"

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

import { Badge } from "@/components/ui/badge"

import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs"

const defaultProducts = [
  {
    id: 1,
    name: "Smartphone",
    description: "Latest smartphone",
    price: 699,
    stock: 15,
    image: "https://placehold.co/100x100",
  },
  {
    id: 2,
    name: "Laptop",
    description: "Gaming laptop",
    price: 999,
    stock: 3,
    image: "https://placehold.co/100x100",
  },
  {
    id: 3,
    name: "Headphones",
    description: "Wireless headphones",
    price: 89,
    stock: 42,
    image: "https://placehold.co/100x100",
  },
  {
    id: 4,
    name: "Keyboard",
    description: "Mechanical keyboard",
    price: 59,
    stock: 7,
    image: "https://placehold.co/100x100",
  },
  {
    id: 5,
    name: "Mouse",
    description: "Gaming mouse",
    price: 29,
    stock: 28,
    image: "https://placehold.co/100x100",
  },
]

const defaultOrders = [
  {
    id: "#1001",
    customer: "John Doe",
    date: "2024-01-15",
    total: 698,
    status: "Pending",
    items: [
      {
        name: "Smartphone",
        quantity: 1,
        subtotal: 698,
      },
    ],
  },
  {
    id: "#1002",
    customer: "Jane Smith",
    date: "2024-01-14",
    total: 999,
    status: "Processing",
    items: [
      {
        name: "Laptop",
        quantity: 1,
        subtotal: 999,
      },
    ],
  },
  {
    id: "#1003",
    customer: "Bob Johnson",
    date: "2024-01-13",
    total: 118,
    status: "Delivered",
    items: [
      {
        name: "Keyboard",
        quantity: 2,
        subtotal: 118,
      },
    ],
  },
  {
    id: "#1004",
    customer: "Alice Brown",
    date: "2024-01-12",
    total: 29,
    status: "Shipped",
    items: [
      {
        name: "Mouse",
        quantity: 1,
        subtotal: 29,
      },
    ],
  },
  {
    id: "#1005",
    customer: "Charlie Wilson",
    date: "2024-01-11",
    total: 59,
    status: "Cancelled",
    items: [
      {
        name: "Keyboard",
        quantity: 1,
        subtotal: 59,
      },
    ],
  },
]

const products = ref(JSON.parse(JSON.stringify(defaultProducts)))
const orders = ref(JSON.parse(JSON.stringify(defaultOrders)))

const search = ref("")

const productDialog = ref(false)
const orderDialog = ref(false)

const editingProduct = ref(null)
const selectedOrder = ref(null)

const formError = ref("")

const productForm = reactive({
  id: null,
  name: "",
  description: "",
  price: 0,
  stock: 0,
  image: "",
})

const currentDate = new Date().toLocaleDateString()

const filteredProducts = computed(() => {
  return products.value.filter(product =>
    product.name
      .toLowerCase()
      .includes(search.value.toLowerCase())
  )
})

const totalProducts = computed(() => products.value.length)

const totalOrders = computed(() => orders.value.length)

const totalRevenue = computed(() => {
  return orders.value.reduce(
    (sum, order) => sum + order.total,
    0
  )
})

const lowStockItems = computed(() => {
  return products.value.filter(
    product => product.stock < 10
  ).length
})

const resetForm = () => {
  productForm.id = null
  productForm.name = ""
  productForm.description = ""
  productForm.price = 0
  productForm.stock = 0
  productForm.image = ""
}

const openAddProduct = () => {
  editingProduct.value = null
  resetForm()
}

const saveProduct = () => {
  formError.value = ""

  if (!productForm.name.trim()) {
    formError.value = "Product name is required."
    return
  }

  if (productForm.price <= 0) {
    formError.value = "Price must be greater than 0."
    return
  }

  if (productForm.stock < 0) {
    formError.value = "Stock cannot be negative."
    return
  }

  if (editingProduct.value) {
    const index = products.value.findIndex(
      p => p.id === productForm.id
    )

    products.value[index] = {
      ...productForm,
    }
  } else {
    products.value.push({
      ...productForm,
      id: Date.now(),
    })
  }

  productDialog.value = false
  resetForm()
}

const editProduct = product => {
  editingProduct.value = product

  productForm.id = product.id
  productForm.name = product.name
  productForm.description = product.description
  productForm.price = product.price
  productForm.stock = product.stock
  productForm.image = product.image

  productDialog.value = true
}

const deleteProduct = id => {
  const confirmed = window.confirm(
    "Are you sure you want to delete this product?"
  )

  if (!confirmed) return

  products.value = products.value.filter(
    product => product.id !== id
  )
}

const viewOrder = order => {
  selectedOrder.value = order
  orderDialog.value = true
}

const resetData = () => {
  products.value = JSON.parse(
    JSON.stringify(defaultProducts)
  )

  orders.value = JSON.parse(
    JSON.stringify(defaultOrders)
  )
}
</script>