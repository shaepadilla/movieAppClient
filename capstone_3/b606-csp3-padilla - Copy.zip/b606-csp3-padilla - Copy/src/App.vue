<template>

    <div class="app-wrapper">

        <!-- NAVBAR -->
        <Navbar />

        <!-- PAGE CONTENT -->
        <main class="main-content">
            <router-view />
        </main>

        <!-- FOOTER -->
        <footer class="footer">

            <div class="container">

                <div class="row">

                    <div class="col-md-4 mb-4">

                        <h5>Digimart</h5>

                        <p>
                            Your trusted online shop for quality
                            gadgets, fashion, and everyday essentials.
                        </p>

                    </div>

                    <div class="col-md-4 mb-4">

                        <h5>Quick Links</h5>

                        <p><router-link to="/">Home</router-link></p>
                        <p><router-link to="/products">Products</router-link></p>
                        <p><router-link to="/cart">Cart</router-link></p>

                    </div>

                    <div class="col-md-4 mb-4">

                        <h5>Contact</h5>

                        <p>support@digimart.com</p>
                        <p>+63 912 345 6789</p>

                    </div>

                </div>

                <div class="footer-bottom">
                    © 2026 Digimart. All Rights Reserved.
                </div>

            </div>

        </footer>

    </div>

</template>

<script setup>

import Navbar from './components/Navbar.vue'

</script>

<style>

html,
body,
#app {
    height: 100%;
    margin: 0;
}

.app-wrapper {
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}

.main-content {
    flex: 1;
}

.footer {
    background: #08122f;
    color: white;
    padding: 60px 0 20px;
}

.footer h5 {
    font-weight: 700;
    margin-bottom: 20px;
}

.footer p,
.footer a {
    color: #d1d5db;
    text-decoration: none;
}

.footer a:hover {
    color: white;
}

.footer-bottom {
    border-top: 1px solid rgba(255,255,255,0.1);
    margin-top: 30px;
    padding-top: 20px;
    text-align: center;
    color: #9ca3af;
}

</style>