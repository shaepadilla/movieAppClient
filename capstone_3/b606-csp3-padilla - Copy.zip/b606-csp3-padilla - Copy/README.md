# Capstone 3 - E-commerce API

A RESTful backend API for an E-commerce application built using Node.js, Express.js, and MongoDB.  
This API handles authentication, product management, cart functionality, checkout processing, and order management.

---

# Tech Stack

- Node.js
- Express.js
- MongoDB Atlas
- Mongoose
- JWT Authentication
- bcrypt
- CORS
- dotenv

---

# Features

## Authentication & Users
- User Registration
- User Login with JWT Authentication
- User Profile Retrieval
- Update User Profile
- Update Password
- Admin Promotion

## Product Management
- Create Products (Admin)
- Retrieve All Products
- Retrieve Active Products
- Retrieve Products by Category
- Retrieve Seasonal Products
- Update Product Information
- Archive/Deactivate Product
- Activate Product
- Search Products by Name
- Search Products by Price Range

## Cart Features
- Add Products to Cart
- Retrieve User Cart
- Update Product Quantity
- Remove Item from Cart
- Clear Entire Cart

## Orders
- Checkout Cart
- Retrieve User Orders
- Retrieve All Orders (Admin)
- Retrieve Single Order
- Update Order Status

---

# Project Setup

## Install Dependencies

```bash
npm install